const API = "http://localhost:8080/reciclagem";

async function carregarDados() {

    const resposta = await fetch(API);

    const dados = await resposta.json();

    const tabela =
        document.getElementById("tabelaDados");

    tabela.innerHTML = "";

    let total = 0;

    dados.forEach((item, index) => {

        total += item.peso;

        tabela.innerHTML += `

            <tr style="animation-delay:${index * 0.1}s">

                <td>${item.id}</td>

                <td>${item.tipo}</td>

                <td>${item.peso} KG</td>

                <td class="acoes">

                    <button onclick="editar(
                        ${item.id},
                        '${item.tipo}',
                        ${item.peso}
                    )">
                        ✏ Editar
                    </button>

                    <button onclick="deletar(${item.id})">
                        🗑 Excluir
                    </button>

                </td>

            </tr>
        `;
    });

    document
        .getElementById("totalPeso")
        .innerText = total;

    animarBarra(total);

    verificarPlaneta(total);
}

/* ======================
   BARRA
====================== */

function animarBarra(total) {

    const barra =
        document.getElementById("barraProgresso");

    let porcentagem = total;

    if (porcentagem > 100) {

        porcentagem = 100;
    }

    barra.style.width =
        porcentagem + "%";
}

/* ======================
   SALVAR
====================== */

async function salvar() {

    const tipo =
        document.getElementById("material").value;

    const peso =
        document.getElementById("peso").value;

    const novo = {

        tipo: tipo,

        peso: parseFloat(peso)
    };

    await fetch(API, {

        method: "POST",

        headers: {

            "Content-Type": "application/json"
        },

        body: JSON.stringify(novo)
    });

    limparCampos();

    carregarDados();
}

/* ======================
   EDITAR
====================== */

function editar(id, tipo, peso) {

    document.getElementById("id").value = id;

    document.getElementById("material").value = tipo;

    document.getElementById("peso").value = peso;

    window.scrollTo({

        top: 0,

        behavior: "smooth"
    });
}

/* ======================
   ATUALIZAR
====================== */

async function atualizar() {

    const id =
        document.getElementById("id").value;

    const tipo =
        document.getElementById("material").value;

    const peso =
        document.getElementById("peso").value;

    const atualizado = {

        tipo: tipo,

        peso: parseFloat(peso)
    };

    await fetch(`${API}/${id}`, {

        method: "PUT",

        headers: {

            "Content-Type": "application/json"
        },

        body: JSON.stringify(atualizado)
    });

    limparCampos();

    carregarDados();
}

/* ======================
   DELETE
====================== */

async function deletar(id) {

    await fetch(`${API}/${id}`, {

        method: "DELETE"
    });

    carregarDados();
}

/* ======================
   LIMPAR
====================== */

function limparCampos() {

    document.getElementById("id").value = "";

    document.getElementById("material").value = "";

    document.getElementById("peso").value = "";
}

/* ======================
   PLANETA
====================== */

function verificarPlaneta(total) {

    const planeta =
        document.getElementById("planeta");

    const status =
        document.getElementById("statusPlaneta");

    limparEfeitos();

    if (total <= 50) {

        planeta.src =
            "https://cdn-icons-png.flaticon.com/512/414/414927.png";

        status.innerText =
            "🌍 Natureza Equilibrada";

        status.style.color = "green";

        criarChuva();

    } else if (total <= 100) {

        planeta.src = "img/signo-de-fogo.png";

        status.innerText =
            "⚠ Poluição Crescendo";

        status.style.color = "orange";

        criarFumaca();

    } else {

        planeta.src =
            "img/signo-de-fogo.png";

        planeta.classList.add("explodindo");

        status.innerText =
            "💥 PLANETA EM COLAPSO";

        status.style.color = "red";

        criarFumacaPesada();
    }
}

function limparEfeitos() {

    document
        .querySelectorAll(".fumaca")
        .forEach(e => e.remove());

    document
        .querySelectorAll(".chuva")
        .forEach(e => e.remove());

    document
        .getElementById("planeta")
        .classList.remove("explodindo");
}

/* ======================
   CHUVA
====================== */

function criarChuva() {

    const area =
        document.getElementById("planetaArea");

    for (let i = 0; i < 60; i++) {

        const chuva =
            document.createElement("div");

        chuva.classList.add("chuva");

        chuva.style.left =
            Math.random() * 100 + "%";

        chuva.style.animationDuration =
            (Math.random() * 2 + 1) + "s";

        area.appendChild(chuva);
    }
}

/* ======================
   FUMAÇA
====================== */

function criarFumaca() {

    const area =
        document.getElementById("planetaArea");

    for (let i = 0; i < 12; i++) {

        const fumaca =
            document.createElement("div");

        fumaca.classList.add("fumaca");

        fumaca.style.left =
            (40 + Math.random() * 20) + "%";

        fumaca.style.bottom =
            "80px";

        area.appendChild(fumaca);
    }
}

/* ======================
   FUMAÇA PESADA
====================== */

function criarFumacaPesada() {

    const area =
        document.getElementById("planetaArea");

    for (let i = 0; i < 30; i++) {

        const fumaca =
            document.createElement("div");

        fumaca.classList.add("fumaca");

        fumaca.style.left =
            Math.random() * 100 + "%";

        fumaca.style.bottom =
            Math.random() * 150 + "px";

        fumaca.style.width =
            40 + Math.random() * 60 + "px";

        fumaca.style.height =
            fumaca.style.width;

        area.appendChild(fumaca);
    }
}

carregarDados();